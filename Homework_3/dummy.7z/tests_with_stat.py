import subprocess
import os

CONFIG_FILE = "config.txt"

def read_config():
    if not os.path.exists(CONFIG_FILE):
        # Значения по умолчанию
        return "-", "-", "zip"
    with open(CONFIG_FILE) as f:
        lines = f.read().strip().splitlines()
        if len(lines) >= 2:
            num_files, file_size = lines[0].strip(), lines[1].strip()
        else:
            num_files, file_size = "-", "-"
        archive_type = lines[2].strip() if len(lines) >= 3 else "zip"
        return num_files, file_size, archive_type


def test_7z_archive_type():
    _, _, archive_type = read_config()
    path_to_7z = r"C:\Program Files (x86)\OpenBox\LibreOffice-x64\7z.exe"  # Полный путь к 7z.exe

    archive_name = f"dummy.{archive_type}"

    # Создаём архив нужного типа, если его ещё нет
    if not os.path.exists(archive_name):
        subprocess.run(
            [path_to_7z, 'a', f'-t{archive_type}', archive_name, 'tests_with_stat.py'],
            capture_output=True,
            text=True
        )

    # Проверяем архив
    result = subprocess.run(
        [path_to_7z, 't', f'-t{archive_type}', archive_name],
        capture_output=True,
        text=True
    )

    print("STDOUT:")
    print(result.stdout)
    print("STDERR:")
    print(result.stderr)

    assert "Everything is Ok" in result.stdout or result.returncode == 0